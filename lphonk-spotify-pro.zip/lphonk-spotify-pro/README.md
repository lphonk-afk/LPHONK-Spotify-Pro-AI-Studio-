# LPHONK Spotify Pro — AI Studio

React + Vite + TypeScript app for creating Spotify-inspired artwork cards, importing Spotify track metadata, generating AI covers, and exporting JPGs in four aspect ratios.

## Local setup

```bash
npm install
npm run dev
```

Production build:

```bash
npm run build
npm run preview
```

## AI cover generation

The serverless endpoint is `api/generate-ai-cover.ts`. Set `AI_COVER_API_KEY` in Vercel Environment Variables. Never put the key in a `VITE_*` variable or in frontend code.

The endpoint applies request validation and a small per-instance in-memory throttle. **This is not a global abuse-prevention system** because Vercel functions can scale across instances. Before a public launch, add a shared rate limiter (for example Redis/Upstash), quotas/authentication, and billing alerts.

The endpoint uses OpenAI's image API and requests base64 output to avoid cross-origin image loading in Canvas. Image model and output options can change by provider/account; verify the selected model is enabled for your API key.

## Spotify import and CORS

Spotify oEmbed is used for public metadata. Browser access to remote thumbnails can be blocked by CORS. If so, upload an image manually or add a server-side image proxy with strict host allowlisting, byte limits, timeouts, and content-type checks. The AI-generated image is returned as a data URL from the serverless endpoint.

## Deployment on Vercel

1. Push this folder to GitHub.
2. Import the repository in Vercel.
3. Add `AI_COVER_API_KEY` to the project's Environment Variables.
4. Deploy and test `/api/generate-ai-cover` and all export ratios.

A successful local TypeScript/Vite build does not by itself verify a live Vercel deployment or API billing/model access.

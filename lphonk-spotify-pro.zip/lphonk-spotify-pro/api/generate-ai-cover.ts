import type { VercelRequest, VercelResponse } from "@vercel/node";

const ALLOWED_STYLES = new Set(["phonk", "brazilian", "montagem"]);
const MAX_PROMPT_LENGTH = 300;
const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
const REQUEST_TIMEOUT_MS = 55_000;

// Best-effort per-instance throttle only. Use a shared store for global rate limiting on Vercel.
const hits = new Map<string, { count: number; resetAt: number }>();
const WINDOW_MS = 60_000;
const MAX_REQUESTS_PER_WINDOW = 5;

function getClientKey(req: VercelRequest): string {
  const forwarded = req.headers["x-forwarded-for"];
  const first = Array.isArray(forwarded) ? forwarded[0] : forwarded?.split(",")[0];
  return (first || req.socket.remoteAddress || "unknown").trim().slice(0, 100);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function rateLimited(key: string): boolean {
  const now = Date.now();
  const existing = hits.get(key);
  if (!existing || existing.resetAt <= now) {
    hits.set(key, { count: 1, resetAt: now + WINDOW_MS });
    if (hits.size > 2000) {
      for (const [k, v] of hits) if (v.resetAt <= now) hits.delete(k);
    }
    return false;
  }
  existing.count += 1;
  return existing.count > MAX_REQUESTS_PER_WINDOW;
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method Not Allowed" });
  }

  const contentLength = Number(req.headers["content-length"] || 0);
  if (Number.isFinite(contentLength) && contentLength > 12_000) {
    return res.status(413).json({ error: "Размер запроса слишком большой" });
  }

  if (rateLimited(getClientKey(req))) {
    return res.status(429).json({ error: "Слишком много запросов. Попробуйте позже." });
  }

  if (!isRecord(req.body)) {
    return res.status(400).json({ error: "Ожидается JSON-объект" });
  }

  const style = req.body.style;
  const prompt = req.body.prompt;
  if (typeof style !== "string" || !ALLOWED_STYLES.has(style)) {
    return res.status(400).json({ error: "Неверный или не поддерживаемый стиль обложки" });
  }
  if (prompt !== undefined && (typeof prompt !== "string" || prompt.length > MAX_PROMPT_LENGTH)) {
    return res.status(400).json({ error: `Промпт должен быть строкой до ${MAX_PROMPT_LENGTH} символов` });
  }

  const apiKey = process.env.AI_COVER_API_KEY || process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "API-ключ генератора не настроен на сервере" });
  }

  const safePrompt = (typeof prompt === "string" && prompt.trim())
    ? prompt.trim()
    : `Phonk music cover art, ${style} aesthetic, cinematic neon lighting, high detail, no text`;

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const aiResponse = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: "gpt-image-1",
        prompt: safePrompt,
        n: 1,
        size: "1024x1024"
      }),
      signal: controller.signal
    });

    const data: unknown = await aiResponse.json().catch(() => null);
    if (!aiResponse.ok) {
      const message = isRecord(data) && isRecord(data.error) && typeof data.error.message === "string"
        ? data.error.message
        : "Ошибка генерации изображения у провайдера";
      return res.status(aiResponse.status >= 500 ? 502 : 400).json({ error: message.slice(0, 500) });
    }

    const first = isRecord(data) && Array.isArray(data.data) ? data.data[0] : undefined;
    if (!isRecord(first)) {
      return res.status(502).json({ error: "Провайдер не вернул изображение" });
    }

    // Prefer base64 response where supported; this avoids remote-image CORS in the browser.
    if (typeof first.b64_json === "string" && first.b64_json.length > 0) {
      const estimatedBytes = Math.floor(first.b64_json.length * 3 / 4);
      if (estimatedBytes > MAX_IMAGE_BYTES) {
        return res.status(502).json({ error: "Сгенерированное изображение слишком большое" });
      }
      return res.status(200).json({ imageBase64: `data:image/png;base64,${first.b64_json}` });
    }

    // Compatibility fallback: only fetch an HTTPS URL from the expected OpenAI asset hosts.
    if (typeof first.url === "string") {
      const imageUrl = new URL(first.url);
      const allowedHosts = new Set(["oaidalleapiprodscus.blob.core.windows.net", "openai.com"]);
      if (imageUrl.protocol !== "https:" ||
          !(imageUrl.hostname.endsWith(".blob.core.windows.net") || allowedHosts.has(imageUrl.hostname))) {
        return res.status(502).json({ error: "Провайдер вернул неподдерживаемый адрес изображения" });
      }

      const imageResponse = await fetch(imageUrl, { signal: controller.signal });
      if (!imageResponse.ok) return res.status(502).json({ error: "Не удалось получить изображение от провайдера" });

      const contentType = imageResponse.headers.get("content-type")?.split(";")[0].trim();
      if (!contentType || !["image/png", "image/jpeg", "image/webp"].includes(contentType)) {
        return res.status(502).json({ error: "Провайдер вернул неподдерживаемый формат изображения" });
      }

      const declaredLength = Number(imageResponse.headers.get("content-length") || 0);
      if (declaredLength > MAX_IMAGE_BYTES) {
        return res.status(502).json({ error: "Сгенерированное изображение слишком большое" });
      }

      const bytes = new Uint8Array(await imageResponse.arrayBuffer());
      if (bytes.byteLength > MAX_IMAGE_BYTES) {
        return res.status(502).json({ error: "Сгенерированное изображение слишком большое" });
      }
      const base64 = Buffer.from(bytes).toString("base64");
      return res.status(200).json({ imageBase64: `data:${contentType};base64,${base64}` });
    }

    return res.status(502).json({ error: "Провайдер не вернул данные изображения" });
  } catch (error: unknown) {
    const aborted = error instanceof Error && error.name === "AbortError";
    return res.status(aborted ? 504 : 502).json({
      error: aborted ? "Генерация заняла слишком много времени" : "Не удалось выполнить генерацию обложки"
    });
  } finally {
    clearTimeout(timeout);
  }
}
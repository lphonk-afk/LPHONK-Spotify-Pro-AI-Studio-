import QRCode from "qrcode";

export type Ratio = "9:16" | "16:9" | "3:4" | "1:1";

export interface RenderOpts {
  image: HTMLImageElement | null;
  ratio: Ratio;
  song: string;
  artist: string;
  color: string;
  current: string;
  total: string;
  tag?: string;
  showPlayerDetails?: boolean;
  trackUrl?: string;
}

export const RATIOS: Ratio[] = ["9:16", "16:9", "3:4", "1:1"];

function adjustAlpha(color: string, alpha: number): string {
  const match = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(color);
  if (!match) return `rgba(239, 68, 68, ${alpha})`;
  let hex = match[1];
  if (hex.length === 3) hex = hex.split("").map((c) => c + c).join("");
  const r = parseInt(hex.slice(0, 2), 16);
  const g = parseInt(hex.slice(2, 4), 16);
  const b = parseInt(hex.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export function isValidSpotifyTrackUrl(value: string): boolean {
  try {
    const parsed = new URL(value.trim());
    const parts = parsed.pathname.split("/").filter(Boolean);
    return parsed.protocol === "https:" &&
      parsed.hostname === "open.spotify.com" &&
      (parsed.port === "" || parsed.port === "443") &&
      parts.length >= 2 &&
      parts[0] === "track" &&
      /^[A-Za-z0-9]{22}$/.test(parts[1]) &&
      !parsed.username && !parsed.password;
  } catch {
    return false;
  }
}

export function normalizeSpotifyTrackUrl(value: string): string {
  if (!isValidSpotifyTrackUrl(value)) throw new Error("Введите корректную ссылку на трек Spotify");
  const parsed = new URL(value.trim());
  return `https://open.spotify.com/track/${parsed.pathname.split("/").filter(Boolean)[1]}`;
}

export async function validateImage(file: File): Promise<HTMLImageElement> {
  if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
    throw new Error("Поддерживаются только форматы JPG, PNG и WEBP");
  }
  if (file.size > 15 * 1024 * 1024) throw new Error("Размер файла не должен превышать 15 MB");

  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("Не удалось прочитать файл"));
    reader.onerror = () => reject(new Error("Ошибка чтения файла"));
    reader.readAsDataURL(file);
  });

  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Файл не является корректным изображением"));
    img.src = dataUrl;
  });
}

export function extractDominantColor(img: HTMLImageElement): string {
  const canvas = document.createElement("canvas");
  canvas.width = 32;
  canvas.height = 32;
  const ctx = canvas.getContext("2d");
  if (!ctx) return "#ef4444";
  try {
    ctx.drawImage(img, 0, 0, 32, 32);
    const pixels = ctx.getImageData(0, 0, 32, 32).data;
    let r = 0, g = 0, b = 0, count = 0;
    for (let i = 0; i < pixels.length; i += 4) {
      if (pixels[i + 3] < 128) continue;
      r += pixels[i]; g += pixels[i + 1]; b += pixels[i + 2]; count++;
    }
    if (!count) return "#ef4444";
    return "#" + [r, g, b].map((n) => Math.round(n / count).toString(16).padStart(2, "0")).join("");
  } catch {
    return "#ef4444";
  }
}

function roundedRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, radius: number) {
  const r = Math.min(radius, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function drawWaveform(ctx: CanvasRenderingContext2D, x: number, y: number, width: number, height: number, color: string) {
  const levels = [0.35,0.6,0.85,1,0.7,0.9,0.5,1,0.8,0.65,0.9,0.75,0.4,0.85,0.5,0.7,0.9,0.55,0.7,0.45,0.65,0.5,0.35,0.45,0.3,0.25,0.35,0.2,0.3,0.4,0.25,0.2];
  const gap = 5;
  const barWidth = Math.max(1, (width - gap * (levels.length - 1)) / levels.length);
  levels.forEach((level, i) => {
    const h = height * level;
    ctx.fillStyle = i / levels.length < 0.75 ? color : "rgba(255,255,255,.2)";
    roundedRect(ctx, x + i * (barWidth + gap), y + (height - h) / 2, barWidth, h, barWidth / 2);
    ctx.fill();
  });
}

async function drawQr(ctx: CanvasRenderingContext2D, url: string, x: number, y: number, size: number) {
  if (!isValidSpotifyTrackUrl(url)) return;
  const cleanUrl = normalizeSpotifyTrackUrl(url);
  const qrData = await QRCode.toDataURL(cleanUrl, { margin: 1, width: 256, errorCorrectionLevel: "M" });
  const qr = await new Promise<HTMLImageElement>((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Не удалось загрузить QR-код"));
    img.src = qrData;
  });
  ctx.fillStyle = "#fff";
  roundedRect(ctx, x, y, size, size, 12);
  ctx.fill();
  ctx.drawImage(qr, x + 7, y + 7, size - 14, size - 14);
}

export async function renderArtwork(canvas: HTMLCanvasElement, opts: RenderOpts): Promise<void> {
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas 2D недоступен");

  const { image, ratio, song, artist, color, current, total, tag = "ffansik x lphonk", showPlayerDetails = false, trackUrl = "" } = opts;
  const dimensions: Record<Ratio, [number, number]> = {
    "9:16": [1080, 1920], "16:9": [1920, 1080], "3:4": [1080, 1440], "1:1": [1080, 1080]
  };
  const [width, height] = dimensions[ratio];
  canvas.width = width;
  canvas.height = height;

  const gradient = ctx.createRadialGradient(width / 2, height / 3, 50, width / 2, height / 2, Math.max(width, height));
  gradient.addColorStop(0, adjustAlpha(color, 0.45));
  gradient.addColorStop(0.55, "#0a070a");
  gradient.addColorStop(1, "#020103");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, width, height);

  const tagText = (tag || "ffansik x lphonk").slice(0, 60);
  ctx.font = "bold 20px Inter, sans-serif";
  const tagWidth = Math.min(width - 40, ctx.measureText(tagText).width + 85);
  const tagX = (width - tagWidth) / 2;
  const tagY = Math.max(24, height * 0.07);
  ctx.fillStyle = "rgba(18,14,20,.9)";
  ctx.strokeStyle = "rgba(255,255,255,.12)";
  roundedRect(ctx, tagX, tagY, tagWidth, 48, 24);
  ctx.fill(); ctx.stroke();
  ctx.fillStyle = color; ctx.font = "22px sans-serif"; ctx.textAlign = "left";
  ctx.fillText("♪", tagX + 18, tagY + 31);
  ctx.fillStyle = "#fff"; ctx.font = "bold 18px Inter, sans-serif";
  ctx.fillText(tagText, tagX + 44, tagY + 30, tagWidth - 55);

  if (!showPlayerDetails) {
    const coverSize = Math.min(width * 0.78, height * 0.46, 840);
    const coverX = (width - coverSize) / 2;
    const coverY = tagY + 78;
    ctx.save();
    ctx.shadowColor = adjustAlpha(color, 0.65); ctx.shadowBlur = 35;
    roundedRect(ctx, coverX, coverY, coverSize, coverSize, 30); ctx.clip();
    if (image) ctx.drawImage(image, coverX, coverY, coverSize, coverSize);
    else {
      const coverGradient = ctx.createLinearGradient(coverX, coverY, coverX + coverSize, coverY + coverSize);
      coverGradient.addColorStop(0, adjustAlpha(color, 0.8));
      coverGradient.addColorStop(1, "#08080b");
      ctx.fillStyle = coverGradient; ctx.fillRect(coverX, coverY, coverSize, coverSize);
      ctx.fillStyle = "#fff"; ctx.textAlign = "center"; ctx.font = "900 56px Inter, sans-serif";
      ctx.fillText("LPHONK", width / 2, coverY + coverSize / 2, coverSize - 40);
    }
    ctx.restore();
    ctx.strokeStyle = adjustAlpha(color, 0.8); ctx.lineWidth = 3;
    roundedRect(ctx, coverX, coverY, coverSize, coverSize, 30); ctx.stroke();

    const pillY = Math.min(height - 170, coverY + coverSize + 28);
    ctx.fillStyle = "rgba(15,12,17,.95)";
    roundedRect(ctx, coverX, pillY, coverSize, 112, 24); ctx.fill();
    ctx.textAlign = "left"; ctx.fillStyle = "#fff";
    let fontSize = 36; ctx.font = `bold ${fontSize}px Inter, sans-serif`;
    const title = (song || "LPHONK TRACK").slice(0, 80);
    while (ctx.measureText(title).width > coverSize - 100 && fontSize > 18) {
      fontSize -= 2; ctx.font = `bold ${fontSize}px Inter, sans-serif`;
    }
    ctx.fillText(title, coverX + 28, pillY + 44, coverSize - 75);
    ctx.font = "500 22px Inter, sans-serif"; ctx.fillStyle = "rgba(255,255,255,.65)";
    ctx.fillText((artist || "LPHONK").slice(0, 70), coverX + 28, pillY + 82, coverSize - 75);
    ctx.textAlign = "right"; ctx.fillStyle = color; ctx.font = "26px sans-serif";
    ctx.fillText("♪", coverX + coverSize - 24, pillY + 66);
  } else {
    const cardWidth = Math.min(width * 0.88, 920);
    const cardHeight = Math.min(height * 0.76, 1280);
    const cardX = (width - cardWidth) / 2;
    const cardY = tagY + 70;
    ctx.fillStyle = "rgba(14,11,15,.96)";
    ctx.strokeStyle = adjustAlpha(color, 0.7); ctx.lineWidth = 3;
    roundedRect(ctx, cardX, cardY, cardWidth, cardHeight, 36); ctx.fill(); ctx.stroke();

    const pad = 48, x = cardX + pad, contentW = cardWidth - pad * 2;
    let y = cardY + 90;
    ctx.textAlign = "left"; ctx.fillStyle = "#fff";
    ctx.font = "bold 42px Inter, sans-serif";
    ctx.fillText((song || "LPHONK TRACK").slice(0, 55), x, y, contentW);
    y += 42; ctx.font = "600 23px Inter, sans-serif"; ctx.fillStyle = "rgba(255,255,255,.6)";
    ctx.fillText((artist || "LPHONK").slice(0, 60), x, y, contentW);
    y += 55; drawWaveform(ctx, x, y, contentW, 65, color);
    y += 100; ctx.fillStyle = "rgba(255,255,255,.18)"; ctx.fillRect(x, y, contentW, 4);
    ctx.fillStyle = color; ctx.fillRect(x, y, contentW * 0.72, 4);
    ctx.fillStyle = "#fff"; ctx.beginPath(); ctx.arc(x + contentW * 0.72, y + 2, 8, 0, Math.PI * 2); ctx.fill();
    y += 34; ctx.font = "18px Inter, sans-serif"; ctx.fillStyle = "rgba(255,255,255,.6)";
    ctx.textAlign = "left"; ctx.fillText(current || "0:00", x, y);
    ctx.textAlign = "right"; ctx.fillText(total || "0:00", x + contentW, y);
    ctx.textAlign = "left"; const footerY = cardY + cardHeight - 135;
    ctx.fillStyle = "#fff"; ctx.font = "bold 20px Inter, sans-serif";
    ctx.fillText("Listening on Spotify", x, footerY);
    ctx.font = "16px Inter, sans-serif"; ctx.fillStyle = "rgba(255,255,255,.6)";
    ctx.fillText("Scan the QR code to open the track", x, footerY + 30, contentW - 150);
    try {
      await drawQr(ctx, trackUrl, cardX + cardWidth - 145, cardY + cardHeight - 145, 105);
    } catch {
      ctx.fillStyle = "rgba(255,255,255,.08)";
      roundedRect(ctx, cardX + cardWidth - 145, cardY + cardHeight - 145, 105, 105, 12); ctx.fill();
    }
  }
}

export async function exportArtwork(opts: RenderOpts): Promise<Blob> {
  const canvas = document.createElement("canvas");
  await renderArtwork(canvas, opts);
  return new Promise((resolve, reject) => {
    canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error("Не удалось экспортировать изображение")), "image/jpeg", 0.95);
  });
}
import { useCallback, useEffect, useRef, useState } from "react";
import { AlertTriangle, Link as LinkIcon, Package, RefreshCw, Sparkles, UploadCloud, Zap } from "lucide-react";
import {
  exportArtwork, extractDominantColor, isValidSpotifyTrackUrl, normalizeSpotifyTrackUrl,
  RATIOS, Ratio, RenderOpts, renderArtwork, validateImage
} from "./lib/renderer";

const label = "mb-1.5 block text-xs font-semibold uppercase tracking-wider text-zinc-400";
const input = "w-full rounded-xl border border-zinc-800 bg-zinc-900 px-4 py-3 text-sm outline-none transition-colors focus:border-red-500";

function download(blob: Blob, name: string) {
  const objectUrl = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = objectUrl;
  anchor.download = name;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(objectUrl), 1500);
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("Не удалось загрузить изображение"));
    image.src = src;
  });
}

export default function App() {
  const [song, setSong] = useState("MONTAGEM SUMAQ");
  const [artist, setArtist] = useState("Hogeraki");
  const [spotifyUrl, setSpotifyUrl] = useState("");
  const [color, setColor] = useState("#ef4444");
  const [current, setCurrent] = useState("1:39");
  const [total, setTotal] = useState("2:00");
  const [tag, setTag] = useState("ffansik x lphonk");
  const [showPlayerDetails, setShowPlayerDetails] = useState(false);
  const [ratio, setRatio] = useState<Ratio>("9:16");
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [busy, setBusy] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);
  const [error, setError] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const previewRef = useRef<HTMLCanvasElement>(null);
  const renderVersion = useRef(0);

  const opts = useCallback((selectedRatio: Ratio = ratio): RenderOpts => ({
    image, ratio: selectedRatio, song: song || "LPHONK TRACK", artist: artist || "LPHONK",
    color, current: current || "0:00", total: total || "0:00", tag, showPlayerDetails, trackUrl: spotifyUrl
  }), [image, ratio, song, artist, color, current, total, tag, showPlayerDetails, spotifyUrl]);

  useEffect(() => {
    const canvas = previewRef.current;
    if (!canvas) return;
    const version = ++renderVersion.current;
    renderArtwork(canvas, opts()).catch((err: unknown) => {
      if (version === renderVersion.current) {
        console.error("Ошибка рендеринга:", err);
        setError("Не удалось обновить предпросмотр.");
      }
    });
    return () => { renderVersion.current++; };
  }, [opts]);

  const handleSpotifyImport = async () => {
    setError(""); setSuccessMsg("");
    if (!isValidSpotifyTrackUrl(spotifyUrl)) {
      setError("Введите ссылку вида https://open.spotify.com/track/ID");
      return;
    }
    setBusy(true);
    try {
      const cleanUrl = normalizeSpotifyTrackUrl(spotifyUrl);
      const response = await fetch(`https://open.spotify.com/oembed?url=${encodeURIComponent(cleanUrl)}`);
      if (!response.ok) throw new Error("Spotify не вернул метаданные для этой ссылки");
      const data: unknown = await response.json();
      if (!data || typeof data !== "object") throw new Error("Не удалось прочитать ответ Spotify");
      const record = data as { title?: unknown; author_name?: unknown; thumbnail_url?: unknown };
      if (typeof record.title === "string" && record.title.trim()) setSong(record.title.trim());
      if (typeof record.author_name === "string" && record.author_name.trim()) setArtist(record.author_name.trim());
      setSpotifyUrl(cleanUrl);
      setSuccessMsg("Метаданные трека импортированы.");

      if (typeof record.thumbnail_url === "string") {
        // Remote thumbnails may be blocked by CORS; if so, manual upload remains available.
        const img = new Image();
        img.crossOrigin = "anonymous";
        const thumbnail = await new Promise<HTMLImageElement>((resolve, reject) => {
          img.onload = () => resolve(img);
          img.onerror = () => reject(new Error("Обложка недоступна из-за CORS. Загрузите её вручную."));
          img.src = record.thumbnail_url as string;
        });
        setImage(thumbnail);
        setColor(extractDominantColor(thumbnail));
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Ошибка импорта Spotify.");
    } finally {
      setBusy(false);
    }
  };

  const handleAiGeneration = async (style: "phonk" | "brazilian" | "montagem") => {
    setAiGenerating(true); setError(""); setSuccessMsg("");
    try {
      const response = await fetch("/api/generate-ai-cover", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ style, prompt: `Phonk music cover art, ${style} aesthetic, cinematic neon lighting, high detail, no text` })
      });
      const data: unknown = await response.json().catch(() => null);
      const record = data && typeof data === "object" ? data as { imageBase64?: unknown; error?: unknown } : {};
      if (!response.ok || typeof record.imageBase64 !== "string") {
        throw new Error(typeof record.error === "string" ? record.error : "Сбой генерации. Проверьте серверный API-ключ.");
      }
      const generated = await loadImage(record.imageBase64);
      setImage(generated);
      setColor(extractDominantColor(generated));
      setSuccessMsg("AI-обложка готова.");
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Не удалось создать AI-обложку.");
    } finally {
      setAiGenerating(false);
    }
  };

  const handleDownload = async (all = false) => {
    setBusy(true); setError("");
    try {
      for (const selected of (all ? RATIOS : [ratio])) {
        download(await exportArtwork(opts(selected)), `${(song || "lphonk_track").replace(/[^a-z0-9_-]+/gi, "_")}_${selected.replace(":", "x")}.jpg`);
        if (all) await new Promise((resolve) => window.setTimeout(resolve, 350));
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Ошибка экспорта изображения.");
    } finally {
      setBusy(false);
    }
  };

  const aspect = {
    "9:16": "aspect-[9/16] max-w-[260px]", "16:9": "aspect-video max-w-full",
    "3:4": "aspect-[3/4] max-w-[320px]", "1:1": "aspect-square max-w-[340px]"
  }[ratio];

  return (
    <main className="min-h-screen bg-black px-4 py-8 text-white sm:py-10">
      <div className="mx-auto max-w-5xl rounded-3xl border border-zinc-800 bg-zinc-950 p-4 shadow-2xl sm:p-6">
        <header className="mb-6 flex items-center gap-3 border-b border-zinc-800 pb-4">
          <div className="rounded-xl border border-red-500/20 bg-red-500/10 p-2.5 text-red-500"><Zap className="h-6 w-6" /></div>
          <div>
            <h1 className="text-lg font-bold tracking-tight sm:text-xl">LPhonk Spotify Pro — AI Studio</h1>
            <p className="text-xs text-zinc-400">Spotify Link Fetcher · AI Cover Studio · QR Code</p>
          </div>
        </header>

        <section className="mb-6 rounded-2xl border border-zinc-800 bg-zinc-900/60 p-4">
          <label className={label}>Импорт по ссылке Spotify</label>
          <div className="flex flex-col gap-2 sm:flex-row">
            <div className="relative flex-1">
              <LinkIcon className="absolute left-3.5 top-3.5 h-4 w-4 text-zinc-500" />
              <input className={`${input} pl-10`} value={spotifyUrl} onChange={(e) => setSpotifyUrl(e.target.value)} placeholder="https://open.spotify.com/track/..." />
            </div>
            <button onClick={handleSpotifyImport} disabled={busy || !spotifyUrl} className="flex items-center justify-center gap-2 rounded-xl bg-green-600 px-5 py-3 text-sm font-bold transition-colors hover:bg-green-500 disabled:opacity-50">
              {busy ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Zap className="h-4 w-4" />} Импорт
            </button>
          </div>
        </section>

        <section className="mb-6 rounded-2xl border border-zinc-800/80 bg-zinc-900/40 p-4">
          <h2 className={label}>AI Cover Studio — генерация обложек</h2>
          <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-3">
            <button onClick={() => handleAiGeneration("phonk")} disabled={aiGenerating} className="flex items-center justify-between rounded-xl border border-red-900/50 bg-red-950/40 p-3 text-left hover:bg-red-900/40 disabled:opacity-50">
              <span><strong className="block text-xs text-red-400">🔥 PHONK AI</strong><small className="text-zinc-400">Красный неон</small></span>
              {aiGenerating ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4 text-red-400" />}
            </button>
            <button onClick={() => handleAiGeneration("brazilian")} disabled={aiGenerating} className="flex items-center justify-between rounded-xl border border-purple-900/50 bg-purple-950/40 p-3 text-left hover:bg-purple-900/40 disabled:opacity-50">
              <span><strong className="block text-xs text-purple-400">💜 BRAZILIAN FUNK AI</strong><small className="text-zinc-400">Фиолетовый неон</small></span>
              {aiGenerating ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4 text-purple-400" />}
            </button>
            <button onClick={() => handleAiGeneration("montagem")} disabled={aiGenerating} className="flex items-center justify-between rounded-xl border border-cyan-900/50 bg-cyan-950/40 p-3 text-left hover:bg-cyan-900/40 disabled:opacity-50">
              <span><strong className="block text-xs text-cyan-400">⚡ MONTAGEM AI</strong><small className="text-zinc-400">Киберпанк 3D</small></span>
              {aiGenerating ? <RefreshCw className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4 text-cyan-400" />}
            </button>
          </div>
        </section>

        <section className="mb-6">
          <h2 className={label}>Формат карточки</h2>
          <div className="grid grid-cols-4 gap-2">
            {RATIOS.map((item) => <button key={item} onClick={() => setRatio(item)} className={`rounded-xl border py-2.5 text-sm font-medium transition-all ${ratio === item ? "border-red-500 bg-red-500 text-white" : "border-zinc-800 bg-zinc-900 text-zinc-400 hover:bg-zinc-800"}`}>{item}</button>)}
          </div>
        </section>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <section className="space-y-4">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div><label className={label}>Название песни</label><input className={input} value={song} onChange={(e) => setSong(e.target.value)} /></div>
              <div><label className={label}>Артист / автор</label><input className={input} value={artist} onChange={(e) => setArtist(e.target.value)} /></div>
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <div><label className={label}>Тег</label><input className={input} value={tag} onChange={(e) => setTag(e.target.value)} /></div>
              <div><label className={label}>Текущее время</label><input className={`${input} text-center`} value={current} onChange={(e) => setCurrent(e.target.value)} /></div>
              <div><label className={label}>Общее время</label><input className={`${input} text-center`} value={total} onChange={(e) => setTotal(e.target.value)} /></div>
            </div>
            <label className="flex items-center justify-between rounded-xl border border-zinc-800 bg-zinc-900 p-3 text-xs font-semibold text-zinc-300">
              Режим плеера (Back Card)
              <input type="checkbox" checked={showPlayerDetails} onChange={(e) => setShowPlayerDetails(e.target.checked)} className="h-5 w-5 accent-red-500" />
            </label>
            <div>
              <label className={label}>Загрузить обложку вручную</label>
              <label className="flex h-28 cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-zinc-800 bg-zinc-900/50 transition-colors hover:bg-zinc-900">
                <UploadCloud className="mb-1 h-7 w-7 text-zinc-400" />
                <p className="text-xs text-zinc-400"><span className="font-semibold text-zinc-200">Нажмите</span> для выбора JPG, PNG или WEBP</p>
                <input type="file" className="hidden" accept="image/jpeg,image/png,image/webp" onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  setError("");
                  try { const img = await validateImage(file); setImage(img); setColor(extractDominantColor(img)); }
                  catch (err) { setError(err instanceof Error ? err.message : "Ошибка загрузки файла"); }
                  e.currentTarget.value = "";
                }} />
              </label>
            </div>
            <button onClick={() => handleDownload(false)} disabled={busy} className="flex w-full items-center justify-center gap-2 rounded-xl bg-red-500 py-4 font-bold shadow-lg shadow-red-500/25 hover:bg-red-600 disabled:opacity-50">
              {busy ? <RefreshCw className="h-5 w-5 animate-spin" /> : <Zap className="h-5 w-5" />} Скачать карточку ({ratio})
            </button>
            <button onClick={() => handleDownload(true)} disabled={busy} className="flex w-full items-center justify-center gap-2 rounded-xl border border-zinc-800 bg-zinc-900 py-3 text-sm font-semibold hover:bg-zinc-800 disabled:opacity-50">
              <Package className="h-4 w-4" /> Скачать все 4 формата
            </button>
          </section>

          <section className="flex flex-col items-center justify-center rounded-2xl border border-zinc-800/80 bg-zinc-900/30 p-4 sm:p-6">
            <span className="mb-4 text-xs font-medium uppercase tracking-wider text-zinc-400">Предпросмотр ({ratio})</span>
            <div className={`w-full ${aspect} overflow-hidden rounded-xl border border-zinc-800 bg-zinc-900 shadow-2xl`}>
              <canvas ref={previewRef} className="h-full w-full object-contain" />
            </div>
          </section>
        </div>

        {(error || successMsg) && <div className={`mt-5 flex items-start gap-2 rounded-xl border p-3 text-sm ${error ? "border-red-900/60 bg-red-950/30 text-red-300" : "border-green-900/60 bg-green-950/20 text-green-300"}`}>
          {error && <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />}
          <span>{error || successMsg}</span>
        </div>}
        <p className="mt-5 text-center text-[11px] text-zinc-600">AI-генерация требует серверного API-ключа. Не публикуйте ключ в клиентском коде.</p>
      </div>
    </main>
  );
}